import json
import os
from datetime import datetime, timezone

import boto3

ec2_client = boto3.client("ec2")
sns_client = boto3.client("sns")

SNS_TOPIC_ARN = os.environ.get("SNS_TOPIC_ARN")


def publish_alert(event_type, detail, action):
    sns_client.publish(
        TopicArn=SNS_TOPIC_ARN,
        Message=json.dumps({
            "event": event_type,
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "detail": detail,
            "action": action,
        }),
    )


# ===== wsc2026-ec2-stop-remediation =====
def ec2_stop_handler(event, context):
    instance_id = os.environ.get("INSTANCE_ID")
    detail = event.get("detail", {})
    state = detail.get("state", "")

    if state != "stopped":
        return

    # TODO: 중지된 EC2 인스턴스를 자동으로 재시작하는 로직 구현
    # ec2_client를 사용하여 instance_id를 시작시키세요

    publish_alert(
        "EC2_STOPPED",
        f"EC2 instance {instance_id} was stopped and restarted",
        "RESTORED",
    )


# ===== wsc2026-ec2-terminate-alert =====
def ec2_terminate_handler(event, context):
    detail = event.get("detail", {})
    instance_id = detail.get("instance-id", "unknown")

    # TODO: SNS 알림을 발송하는 로직 구현
    # publish_alert()를 사용하여 EC2_TERMINATED 이벤트 알림을 발송하세요
    # action은 "ALERT_ONLY"


# ===== wsc2026-sg-remediation =====
def sg_remediation_handler(event, context):
    sg_id = os.environ.get("SECURITY_GROUP_ID")
    detail = event.get("detail", {})

    compliance = detail.get("newEvaluationResult", {}).get("complianceType", "")
    if compliance != "NON_COMPLIANT":
        return

    # TODO: Security Group에서 SSH(22) 0.0.0.0/0 인바운드 규칙을 삭제하는 로직 구현
    # ec2_client.revoke_security_group_ingress()를 사용하세요
    # Protocol: tcp, Port: 22, CIDR: 0.0.0.0/0

    publish_alert(
        "SG_SSH_OPEN",
        f"Unauthorized SSH rule removed from {sg_id}",
        "RESTORED",
    )


# ===== wsc2026-tag-alert =====
def tag_alert_handler(event, context):
    detail = event.get("detail", {})
    resource_id = detail.get("resourceId", "unknown")

    compliance = detail.get("newEvaluationResult", {}).get("complianceType", "")
    if compliance != "NON_COMPLIANT":
        return

    # TODO: SNS 알림을 발송하는 로직 구현
    # publish_alert()를 사용하여 TAG_MISSING 이벤트 알림을 발송하세요
    # detail에 resource_id를 포함하고, action은 "ALERT_ONLY"
