# Lambda

## 개요
EventBridge Rule 및 AWS Config Rule에 의해 호출되는 Lambda 함수 4개를 직접 개발합니다. 각 함수는 정책 위반 이벤트를 수신하여 자동 복구를 수행하고, SNS Topic에 알림 메시지를 Publish해야 합니다.

## Lambda Functions

| Function Name | Trigger | Action |
|---------------|---------|--------|
| wsc2026-ec2-stop-remediation | wsc2026-ec2-stop-rule (EventBridge) | EC2 자동 재시작 + 알림 |
| wsc2026-ec2-terminate-alert | wsc2026-ec2-terminate-rule (EventBridge) | 알림 발송 |
| wsc2026-sg-remediation | wsc2026-sg-ssh-rule (Config) | 위반 인바운드 규칙 삭제 + 알림 |
| wsc2026-tag-alert | wsc2026-required-tags-rule (Config) | 알림 발송 |

- Runtime: Python 3.12
- Handler: index.handler

## Lambda Function Environment
다음 환경변수들을 함수에 사용해야합니다.

| Function | Environment | Value |
|----------|-------------|-------|
| Every Function | SNS_TOPIC_ARN | SNS Topic ARN |
| wsc2026-ec2-stop-remediation | INSTANCE_ID | EC2 Instance ID |
| wsc2026-sg-remediation | SECURITY_GROUP_ID | EC2 Security Group ID |

## EventBridge 이벤트 형식

### EC2 State Change (wsc2026-ec2-stop-rule, wsc2026-ec2-terminate-rule)

```json
{
  "source": "aws.ec2",
  "detail-type": "EC2 Instance State-change Notification",
  "detail": {
    "instance-id": "i-0123456789abcdef0",
    "state": "stopped"
  }
}
```

## AWS Config 이벤트 형식

### Config Rule Compliance Change (wsc2026-sg-remediation, wsc2026-tag-alert)

```json
{
  "source": "aws.config",
  "detail-type": "Config Rules Compliance Change",
  "detail": {
    "configRuleName": "wsc2026-sg-ssh-rule",
    "resourceType": "AWS::EC2::SecurityGroup",
    "resourceId": "sg-0123456789abcdef0",
    "newEvaluationResult": {
      "complianceType": "NON_COMPLIANT"
    }
  }
}
```

## SNS Message Form

```json
{
    "event": "EC2_STOPPED",
    "timestamp": "2026-05-26T15:30:00Z",
    "detail": "EC2 instance i-xxx was stopped and restarted",
    "action": "RESTORED"
}
```

| Field | Description |
|-------|-------------|
| event | EC2_STOPPED / EC2_TERMINATED / SG_SSH_OPEN / TAG_MISSING |
| timestamp | 이벤트 발생 시각 (ISO 8601) |
| detail | 위반 상세 내용 |
| action | RESTORED / ALERT_ONLY |

## 각 함수별 처리 로직

### wsc2026-ec2-stop-remediation
1. EventBridge에서 EC2 State-change 이벤트 수신 (state: stopped)
2. EC2 인스턴스 자동 재시작 (`start_instances`)
3. SNS 알림 발송

### wsc2026-ec2-terminate-alert
1. EventBridge에서 EC2 State-change 이벤트 수신 (state: terminated)
2. SNS 알림 발송

### wsc2026-sg-remediation
1. Config Rules Compliance Change 이벤트 수신 (NON_COMPLIANT)
2. Security Group에서 SSH(22) 0.0.0.0/0 인바운드 규칙 삭제
3. SNS 알림 발송

### wsc2026-tag-alert
1. Config Rules Compliance Change 이벤트 수신 (NON_COMPLIANT)
2. SNS 알림 발송 (태그 미준수 리소스 정보 포함)
